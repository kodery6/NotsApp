package com.example.kyle.unnamed;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

/**
 * Created by kyle on 17/3/18.
 */

public class RegisterActivity extends AppCompatActivity {

    private Button signIn_page;
    private Button signIn;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_activity);

        signIn_page = (Button) findViewById(R.id.signIn_page);
        signIn_page.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSignInPageActivity();
            }
        });

        signIn = (Button) findViewById(R.id.signIn_button);
        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSignInActivity();
            }
        });
    }

    public void openSignInPageActivity() {
        Intent intent_signIn = new Intent(this, LoginActivity.class);
        startActivity(intent_signIn);
    }

    public void openSignInActivity() {
        Intent intent_homepage = new Intent(this, HomePage.class);
        startActivity(intent_homepage);
    }
}
