package com.example.kyle.unnamed;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

/**
 * Created by kyle on 16/3/18.
 */

public class LoginActivity extends AppCompatActivity {

    private Button register;
    private Button signIn;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

        register = (Button) findViewById(R.id.register_button);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openRegisterActivity();
            }
        });

        signIn = (Button) findViewById(R.id.signIn_button);
        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSignInActivity();
            }
        });
    }

    public void openRegisterActivity() {
        Intent intent_register = new Intent(this, RegisterActivity.class);
        startActivity(intent_register);
    }

    public void openSignInActivity() {
        Intent intent_homepage = new Intent(this, HomePage.class);
        startActivity(intent_homepage);
    }
}
